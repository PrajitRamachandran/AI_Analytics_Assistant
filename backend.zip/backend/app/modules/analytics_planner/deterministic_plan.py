"""Deterministic fallback plan construction for empty LLM plans.

This module selects only operations supported by the existing V1 schema and
profile. It does not calculate results; Module 5 remains the sole calculation
engine. It is intentionally conservative about identifiers, free text and
high-cardinality categories.
"""

from __future__ import annotations

import re
from typing import Optional

from app.modules.analytics_planner.worksheet_classifier import classify_worksheet
from app.schemas.analytics_plan import (
    AverageOperation,
    CountOperation,
    GroupByOperation,
    KPIRecommendation,
    MetricAggregation,
    VisualizationRecommendation,
    WorkbookAnalyticsPlan,
)
from app.schemas.data_understanding import DatasetProfile, WorksheetProfile


_EXCLUDED_DIMENSION = re.compile(
    r"(^|_)(id|uuid|guid|code|key|name|notes?|comment|description|email|"
    r"address|date|time|timestamp)(_|$)",
    re.IGNORECASE,
)
_DIMENSION_PREFERENCE = re.compile(
    r"attendance|status|department|region|category|type|segment|group|channel",
    re.IGNORECASE,
)
_METRIC_PREFERENCE = re.compile(
    r"duration|hours?|quantity|units?|amount|reimbursement|revenue|sales|value|total|"
    r"score|count|cost|profit|expense",
    re.IGNORECASE,
)
_METRIC_STRONG_PREFERENCE = re.compile(r"duration|work_hours|hours", re.IGNORECASE)
_METRIC_AVOID = re.compile(r"(?:^|_)(completion|rate|percentage|ratio)(?:_|$)", re.IGNORECASE)


def _analytical_worksheets(profile: DatasetProfile) -> list[WorksheetProfile]:
    return [
        worksheet
        for name, worksheet in profile.worksheets.items()
        if classify_worksheet(name, worksheet)["role"] == "analytical"
    ]


def _choose_metric(worksheet: WorksheetProfile):
    candidates = []
    for column in worksheet.columns:
        if (
            column.inferred_type != "numerical"
            or column.semantic_role == "identifier"
            or column.non_null_count < 2
            or column.numerical_statistics is None
            or column.numerical_statistics.mean is None
        ):
            continue
        name = column.column_name
        score = 0
        if _METRIC_PREFERENCE.search(name):
            score += 4
        if _METRIC_STRONG_PREFERENCE.search(name):
            score += 5
        if column.semantic_role in {"quantity", "amount", "measure"}:
            score += 2
        if _METRIC_AVOID.search(name):
            score -= 5
        if column.missing_percentage > 40:
            score -= 2
        if column.mixed_value_types:
            score -= 1
        candidates.append((score, column.column_name))
    if not candidates:
        return None
    candidates.sort(key=lambda item: (-item[0], item[1]))
    return candidates[0][1]


def _choose_dimension(worksheet: WorksheetProfile) -> Optional[str]:
    candidates = []
    for column in worksheet.columns:
        if (
            column.inferred_type not in {"categorical", "boolean"}
            or column.semantic_role == "identifier"
            or _EXCLUDED_DIMENSION.search(column.column_name)
        ):
            continue
        unique_count = int(column.unique_value_count)
        non_null_count = int(column.non_null_count)
        if unique_count < 2 or unique_count > 15 or non_null_count < 2:
            continue
        if unique_count / max(non_null_count, 1) > 0.85:
            continue
        score = 0
        if _DIMENSION_PREFERENCE.search(column.column_name):
            score += 5
        if unique_count <= 10:
            score += 2
        if column.missing_percentage > 40:
            score -= 2
        candidates.append((score, column.column_name))
    if not candidates:
        return None
    candidates.sort(key=lambda item: (-item[0], item[1]))
    return candidates[0][1]


def build_deterministic_fallback_plan(
    dataset_profile: DatasetProfile,
    generated_plan: WorkbookAnalyticsPlan,
) -> Optional[WorkbookAnalyticsPlan]:
    """Replace an empty LLM plan with grounded, schema-valid V1 operations.

    Returns ``None`` when the workbook genuinely has no eligible analytical
    worksheet/operation. Worksheet narratives and business context from the
    LLM are retained; all operation choices are derived from Module 3 metadata.
    """

    worksheets = _analytical_worksheets(dataset_profile)
    if not worksheets:
        return None

    operations = []
    kpis = []
    visualizations = []

    # Prefer one meaningful scalar KPI from the strongest profiled measure.
    metric_choice = None
    metric_sheet = None
    for worksheet in worksheets:
        metric = _choose_metric(worksheet)
        if metric is not None:
            metric_choice = metric
            metric_sheet = worksheet
            break

    if metric_choice and metric_sheet:
        metric_column = next(
            column for column in metric_sheet.columns
            if column.column_name == metric_choice
        )
        operation_id = "fallback_average_metric"
        operations.append(
            AverageOperation(
                id=operation_id,
                operation_type="average",
                worksheet_name=metric_sheet.worksheet_name,
                title=f"Average {metric_column.original_name}",
                description=(
                    f"Calculate the mean of the profiled numerical measure "
                    f"'{metric_column.original_name}' using valid numeric values."
                ),
                result_name="average_metric",
                column=metric_choice,
            )
        )
        kpis.append(
            KPIRecommendation(
                id="average_metric",
                operation_id=operation_id,
                label=f"Average {metric_column.original_name}",
                description="Mean of non-missing values accepted by the deterministic executor.",
                format_hint="decimal",
                priority="high",
            )
        )

    # If a usable dimension exists, provide a grouped record-count chart.
    # A count chart remains valid even if no safe numeric measure exists.
    dimension_sheet = None
    dimension_column = None
    for worksheet in worksheets:
        dimension = _choose_dimension(worksheet)
        if dimension is not None:
            dimension_sheet = worksheet
            dimension_column = dimension
            break

    if dimension_sheet and dimension_column:
        operations.append(
            GroupByOperation(
                id="fallback_grouped_record_count",
                operation_type="group_by",
                worksheet_name=dimension_sheet.worksheet_name,
                title=f"Records by {dimension_column.replace('_', ' ').title()}",
                description="Count records in each observed category.",
                group_by_columns=[dimension_column],
                aggregations=[
                    MetricAggregation(
                        alias="record_count",
                        function="count",
                        column=None,
                    )
                ],
            )
        )
        visualizations.append(
            VisualizationRecommendation(
                id="fallback_category_distribution",
                operation_id="fallback_grouped_record_count",
                chart_type="bar",
                title=f"Records by {dimension_column.replace('_', ' ').title()}",
                description="Distribution of records across observed categories.",
                priority="high",
            )
        )

    # A count KPI is the final fallback for a sheet with no safe measure.
    if not operations:
        worksheet = worksheets[0]
        count_id = "fallback_record_count"
        operations.append(
            CountOperation(
                id=count_id,
                operation_type="count",
                worksheet_name=worksheet.worksheet_name,
                title="Records analyzed",
                description="Count rows in the selected analytical worksheet.",
                result_name="record_count",
                column=None,
            )
        )
        kpis.append(
            KPIRecommendation(
                id="record_count",
                operation_id=count_id,
                label="Records analyzed",
                description="Number of rows in the selected analytical worksheet.",
                format_hint="integer",
                priority="high",
            )
        )

    limitations = list(generated_plan.limitations)
    limitations.append(
        "The language model returned no executable operations; a conservative "
        "profile-grounded fallback plan was generated deterministically."
    )

    return WorkbookAnalyticsPlan(
        plan_version=generated_plan.plan_version,
        workbook_summary=generated_plan.workbook_summary,
        business_context=generated_plan.business_context,
        worksheet_analyses=generated_plan.worksheet_analyses,
        operations=operations[:2],
        kpis=kpis[:4],
        visualizations=visualizations[:1],
        key_questions=generated_plan.key_questions,
        limitations=limitations[:15],
    )
