"""Deterministic execution of validated Module 4 analytical plans.

The LLM proposes operations only. All calculations in this module are performed
against the cleaned Pandas DataFrames produced by Module 2.
"""
from __future__ import annotations

from typing import Any
import math

import numpy as np
import pandas as pd

from app.schemas.analytics_plan import (
    AverageOperation, BottomNOperation, ComparisonOperation, CountOperation,
    DistinctCountOperation, GroupByOperation, MaxOperation, MinOperation,
    PercentageOfTotalOperation, ScalarOperation, SumOperation,
    TimeSeriesOperation, TopNOperation, WorkbookAnalyticsPlan,
)


class AnalyticsExecutionError(ValueError):
    """Raised when a validated analytical operation cannot be executed."""


def _json_value(value: Any) -> Any:
    if value is None:
        return None
    if isinstance(value, (pd.Timestamp,)):
        return value.isoformat()
    if isinstance(value, np.generic):
        value = value.item()
    try:
        if pd.isna(value):
            return None
    except (TypeError, ValueError):
        pass
    if isinstance(value, float) and not math.isfinite(value):
        return None
    if isinstance(value, (str, int, float, bool)):
        return value
    return str(value)


def _aggregate(series: pd.Series, function: str) -> Any:
    """Apply a supported aggregation while preventing string concatenation/Inf."""
    values = series.dropna()
    if function in {"sum", "average"}:
        values = pd.to_numeric(values, errors="coerce")
        values = values[np.isfinite(values.astype(float, copy=False))]
    elif function in {"min", "max"} and pd.api.types.is_numeric_dtype(values.dtype):
        numeric = pd.to_numeric(values, errors="coerce")
        values = numeric[np.isfinite(numeric.astype(float, copy=False))]

    if function == "sum":
        return values.sum() if len(values) else 0
    if function == "average":
        return values.mean() if len(values) else None
    if function == "count":
        return int(series.count())
    if function == "min":
        return values.min() if len(values) else None
    if function == "max":
        return values.max() if len(values) else None
    if function == "distinct_count":
        return int(values.nunique())
    raise AnalyticsExecutionError(f"Unsupported aggregation: {function}")


def _group_aggregate(
    frame: pd.DataFrame,
    group_columns: list[str],
    function: str,
    column: str | None,
    alias: str,
) -> pd.DataFrame:
    grouped = frame.groupby(group_columns, dropna=False, observed=True)
    if function == "count" and column is None:
        result = grouped.size().rename(alias)
    else:
        if column is None:
            raise AnalyticsExecutionError(
                f"Aggregation '{function}' requires a source column."
            )
        source = frame[column]
        if function in {"sum", "average"}:
            frame = frame.copy()
            frame[column] = pd.to_numeric(source, errors="coerce")
            finite = np.isfinite(frame[column].astype(float, copy=False))
            frame.loc[~finite, column] = np.nan
            grouped = frame.groupby(group_columns, dropna=False, observed=True)
        aggregate_name = (
            "mean" if function == "average" else
            "nunique" if function == "distinct_count" else function
        )
        result = grouped[column].agg(aggregate_name).rename(alias)
    return result.reset_index()


def _execute_scalar(frame: pd.DataFrame, operation: ScalarOperation) -> dict:
    if isinstance(operation, CountOperation):
        value = len(frame) if operation.column is None else int(frame[operation.column].count())
    elif isinstance(operation, SumOperation):
        value = _aggregate(frame[operation.column], "sum")
    elif isinstance(operation, AverageOperation):
        value = _aggregate(frame[operation.column], "average")
    elif isinstance(operation, MinOperation):
        value = _aggregate(frame[operation.column], "min")
    elif isinstance(operation, MaxOperation):
        value = _aggregate(frame[operation.column], "max")
    elif isinstance(operation, DistinctCountOperation):
        value = _aggregate(frame[operation.column], "distinct_count")
    else:
        raise AnalyticsExecutionError(
            f"Unsupported scalar operation: {operation.operation_type}"
        )
    return {
        "operation_id": operation.id,
        "title": operation.title,
        "operation_type": operation.operation_type,
        "worksheet_name": operation.worksheet_name,
        "result_name": operation.result_name,
        "value": _json_value(value),
        "row_count": int(len(frame)),
    }


def _execute_group_by(frame: pd.DataFrame, operation: GroupByOperation) -> list[dict]:
    result: pd.DataFrame | None = None
    for aggregation in operation.aggregations:
        part = _group_aggregate(
            frame,
            operation.group_by_columns,
            aggregation.function,
            aggregation.column,
            aggregation.alias,
        )
        if result is None:
            result = part
        else:
            result = result.merge(part, on=operation.group_by_columns, how="outer")
    if result is None:
        return []
    return [
        {str(k): _json_value(v) for k, v in row.items()}
        for row in result.to_dict(orient="records")
    ]


def _execute_time_series(frame: pd.DataFrame, operation: TimeSeriesOperation) -> list[dict]:
    working = frame.copy()
    # utc=True handles mixed timezone offsets consistently. Convert back to
    # timezone-naive UTC before Period conversion to avoid pandas warnings.
    dates = pd.to_datetime(
        working[operation.date_column],
        errors="coerce",
        format="mixed",
        utc=True,
    ).dt.tz_convert(None)
    valid_dates = dates.notna()
    working = working.loc[valid_dates].copy()
    working["_analytics_period"] = dates.loc[valid_dates].dt.to_period({
        "day": "D", "week": "W-SUN", "month": "M",
        "quarter": "Q", "year": "Y",
    }[operation.interval]).astype(str)
    group_columns = ["_analytics_period", *operation.group_by_columns]
    result = _group_aggregate(
        working,
        group_columns,
        operation.metric.function,
        operation.metric.column,
        operation.metric.alias,
    )
    result = result.rename(columns={"_analytics_period": "period"})
    result = result.sort_values("period")
    return [
        {str(k): _json_value(v) for k, v in row.items()}
        for row in result.to_dict(orient="records")
    ]


def _execute_ranking(
    frame: pd.DataFrame,
    operation: TopNOperation | BottomNOperation,
) -> list[dict]:
    result = _group_aggregate(
        frame,
        [operation.group_by_column],
        operation.metric.function,
        operation.metric.column,
        operation.metric.alias,
    )
    result = result.sort_values(
        operation.metric.alias,
        ascending=isinstance(operation, BottomNOperation),
        na_position="last",
    ).head(operation.limit)
    return [
        {str(k): _json_value(v) for k, v in row.items()}
        for row in result.to_dict(orient="records")
    ]


def _execute_percentage(frame: pd.DataFrame, operation: PercentageOfTotalOperation) -> list[dict]:
    values = pd.to_numeric(frame[operation.value_column], errors="coerce")
    values = values.where(np.isfinite(values.astype(float, copy=False)))
    working = frame.assign(_analytics_value=values)
    grouped = working.groupby(
        operation.category_column,
        dropna=False,
        observed=True,
    )["_analytics_value"].sum(min_count=1)
    total = grouped.sum(min_count=1)
    if total is None or pd.isna(total) or total == 0:
        percentages = grouped * np.nan
    else:
        percentages = grouped / total * 100
    result = pd.DataFrame({
        operation.category_column: grouped.index,
        operation.result_name: percentages.values,
    })
    return [
        {str(k): _json_value(v) for k, v in row.items()}
        for row in result.to_dict(orient="records")
    ]


def _execute_comparison(frame: pd.DataFrame, operation: ComparisonOperation) -> list[dict]:
    rows = []
    for label, category_value in (
        ("baseline", operation.baseline_value),
        ("comparison", operation.comparison_value),
    ):
        subset = frame.loc[frame[operation.category_column] == category_value]
        metric = operation.metric
        value = (
            len(subset) if metric.function == "count" and metric.column is None
            else _aggregate(subset[metric.column], metric.function)
        )
        rows.append({
            operation.category_column: _json_value(category_value),
            "comparison_group": label,
            metric.alias: _json_value(value),
        })
    return rows


def execute_operation(
    worksheets: dict[str, pd.DataFrame],
    operation: Any,
) -> dict:
    """Execute one validated operation and return JSON-safe records."""
    frame = worksheets.get(operation.worksheet_name)
    if frame is None:
        raise AnalyticsExecutionError(
            f"Worksheet '{operation.worksheet_name}' is unavailable for execution."
        )

    if isinstance(operation, ScalarOperation):
        return _execute_scalar(frame, operation)

    if isinstance(operation, GroupByOperation):
        records = _execute_group_by(frame, operation)
    elif isinstance(operation, TimeSeriesOperation):
        records = _execute_time_series(frame, operation)
    elif isinstance(operation, (TopNOperation, BottomNOperation)):
        records = _execute_ranking(frame, operation)
    elif isinstance(operation, PercentageOfTotalOperation):
        records = _execute_percentage(frame, operation)
    elif isinstance(operation, ComparisonOperation):
        records = _execute_comparison(frame, operation)
    else:
        raise AnalyticsExecutionError(
            f"Unsupported operation type: {operation.operation_type}"
        )

    return {
        "operation_id": operation.id,
        "title": operation.title,
        "operation_type": operation.operation_type,
        "worksheet_name": operation.worksheet_name,
        "row_count": int(len(frame)),
        "records": records,
    }


def _chart_from_result(
    operation: Any,
    result: dict,
    recommendation: Any | None = None,
) -> dict | None:
    if "records" not in result or not result["records"]:
        return None
    records = result["records"]

    if isinstance(operation, TimeSeriesOperation):
        x_key = "period"
        y_key = operation.metric.alias
        default_type = "line"
    elif isinstance(operation, GroupByOperation):
        x_key = operation.group_by_columns[0]
        y_key = operation.aggregations[0].alias
        default_type = "bar"
    elif isinstance(operation, (TopNOperation, BottomNOperation)):
        x_key = operation.group_by_column
        y_key = operation.metric.alias
        default_type = "bar"
    elif isinstance(operation, PercentageOfTotalOperation):
        x_key = operation.category_column
        y_key = operation.result_name
        default_type = "bar"
    elif isinstance(operation, ComparisonOperation):
        x_key = operation.category_column
        y_key = operation.metric.alias
        default_type = "bar"
    else:
        return None

    chart_type = recommendation.chart_type if recommendation else default_type
    # The V1 React renderer currently implements bar and line/area charts.
    # Do not label a bar rendering as pie/donut/table.
    if chart_type == "area":
        chart_type = "line"
    elif chart_type not in {"bar", "line"}:
        chart_type = default_type

    points = []
    for row in records:
        value = row.get(y_key)
        if isinstance(value, (int, float)) and math.isfinite(float(value)):
            points.append({"label": str(row.get(x_key, "Unknown")), "value": float(value)})
    if not points:
        return None
    if default_type == "bar":
        points.sort(key=lambda point: point["value"], reverse=True)

    return {
        "id": recommendation.id if recommendation else f"auto_{operation.id}",
        "operation_id": operation.id,
        "title": recommendation.title if recommendation else operation.title,
        "chart_type": chart_type,
        "description": recommendation.description if recommendation else operation.description,
        "priority": recommendation.priority if recommendation else "medium",
        "worksheet_name": operation.worksheet_name,
        "x_label": x_key,
        "y_label": y_key,
        "data": points[:30],
    }


def execute_analytics_plan(
    worksheets: dict[str, pd.DataFrame],
    plan: WorkbookAnalyticsPlan,
) -> dict:
    """Execute all operations and create chart-ready series from actual results."""
    results = []
    result_by_id = {}
    for operation in plan.operations:
        result = execute_operation(worksheets, operation)
        results.append(result)
        result_by_id[operation.id] = result

    recommendations = {item.operation_id: item for item in plan.visualizations}
    charts = []
    charted = set()
    for operation in plan.operations:
        recommendation = recommendations.get(operation.id)
        chart = _chart_from_result(
            operation, result_by_id[operation.id], recommendation
        )
        if chart:
            charts.append(chart)
            charted.add(operation.id)

    # Provide a sensible chart for additional chartable operations even when
    # the LLM chooses to recommend only one. The chart is still based solely
    # on deterministic operation results.
    for operation in plan.operations:
        if operation.id in charted:
            continue
        chart = _chart_from_result(operation, result_by_id[operation.id])
        if chart:
            charts.append(chart)

    kpis = [{
        "id": "rows_analyzed",
        "label": "Rows analyzed",
        "value": sum(len(frame) for frame in worksheets.values()),
        "format_hint": "integer",
    }]
    for result in results:
        if "value" in result:
            kpis.append({
                "id": f"operation_{result['operation_id']}",
                "label": result.get("title", result["result_name"]),
                "value": result["value"],
                "format_hint": "number",
            })

    return {
        "plan": plan.model_dump(mode="json"),
        "results": results,
        "kpis": kpis,
        "charts": charts,
        "worksheet_count": len(worksheets),
        "row_count": sum(len(frame) for frame in worksheets.values()),
    }
