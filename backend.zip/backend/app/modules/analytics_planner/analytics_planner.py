
"""Orchestration layer for the AI analytics planner."""

from __future__ import annotations

import logging
from typing import Protocol

from app.modules.analytics_planner.errors import PlanSchemaValidationError
from app.modules.analytics_planner.deterministic_plan import (
    build_deterministic_fallback_plan,
)
from app.modules.analytics_planner.ollama_client import (
    OllamaClient,
    OllamaConnectionError,
    OllamaTimeoutError,
    create_ollama_client,
)
from app.modules.analytics_planner.plan_validator import (
    AnalyticalPlanValidationError,
    validate_analytical_plan,
)
from app.modules.analytics_planner.profile_preparation import (
    DatasetProfilePreparer,
    ProfilePreparationError,
)
from app.modules.analytics_planner.prompt_builder import (
    AnalyticsPromptBuilder,
    PromptBuilderError,
)
from app.schemas.analytics_plan import WorkbookAnalyticsPlan
from app.schemas.data_understanding import DatasetProfile


logger = logging.getLogger(__name__)


class PlanGenerator(Protocol):
    """Provider-neutral contract for structured analytics-plan generation."""

    def generate_plan(
        self,
        messages: list[dict[str, str]],
    ) -> WorkbookAnalyticsPlan:
        ...


class AnalyticsPlannerError(Exception):
    """Base exception for analytics planner failures."""


class AnalyticsPlanningError(AnalyticsPlannerError):
    """Raised when analytics plan generation fails."""


class AnalyticsPlanningTimeoutError(AnalyticsPlanningError):
    """Raised when the configured LLM provider exceeds its inference timeout."""


class AnalyticsProviderUnavailableError(AnalyticsPlanningError):
    """Raised when the configured LLM provider cannot be reached."""


class AnalyticsPlanner:
    """
    Coordinate profile preparation, prompt construction, LLM inference,
    and analytical plan validation.
    """

    def __init__(
        self,
        profile_preparer: DatasetProfilePreparer | None = None,
        prompt_builder: AnalyticsPromptBuilder | None = None,
        ollama_client: OllamaClient | None = None,
        plan_generator: PlanGenerator | None = None,
    ) -> None:
        self.profile_preparer = (
            profile_preparer or DatasetProfilePreparer()
        )

        self.prompt_builder = (
            prompt_builder or AnalyticsPromptBuilder()
        )

        if plan_generator is not None and ollama_client is not None:
            raise ValueError(
                "Provide either plan_generator or ollama_client, not both."
            )

        # Provider-neutral seam: Ollama is the current adapter, while another
        # implementation (e.g. Mistral) can satisfy PlanGenerator unchanged.
        self.plan_generator: PlanGenerator = (
            plan_generator or ollama_client or create_ollama_client()
        )
        # Backward-compatible attribute for existing diagnostics/callers.
        self.ollama_client = self.plan_generator

    def generate_plan(
        self,
        dataset_profile: DatasetProfile,
    ) -> WorkbookAnalyticsPlan:
        """
        Generate and validate a workbook-level analytics plan.

        The LLM proposes analytical operations but does not execute
        calculations or generate numerical results.
        """

        if not isinstance(dataset_profile, DatasetProfile):
            raise TypeError(
                "dataset_profile must be a DatasetProfile instance."
            )

        logger.info("Starting analytics plan generation.")

        # Step 1: Prepare the Module 3 profile.
        try:
            prepared_profile = self.profile_preparer.prepare(
                dataset_profile
            )

        except ProfilePreparationError:
            logger.exception("Dataset profile preparation failed.")
            raise

        # Step 2: Build LLM messages.
        try:
            messages = self.prompt_builder.build_messages(
                prepared_profile
            )

        except PromptBuilderError:
            logger.exception("Analytics prompt construction failed.")
            raise

        # Step 3: Generate a structured plan and validate it against the real
        # dataset. One correction attempt is allowed for either schema or
        # dataset-validation failures; retries are bounded to avoid loops.
        request_messages = list(messages)
        analytical_plan: WorkbookAnalyticsPlan | None = None

        for attempt in range(2):
            try:
                analytical_plan = self.plan_generator.generate_plan(
                    request_messages
                )

            except PlanSchemaValidationError as exc:
                if attempt == 1:
                    logger.exception(
                        "Generated analytics plan failed schema validation after correction."
                    )
                    raise AnalyticsPlanningError(
                        "The generated analytics plan still failed schema validation "
                        "after one correction attempt."
                    ) from exc

                logger.warning(
                    "Generated plan failed Pydantic schema validation; "
                    "requesting one corrected plan. Errors: %s",
                    exc.validation_errors,
                )
                request_messages = [
                    *messages,
                    {
                        "role": "assistant",
                        "content": exc.generated_output,
                    },
                    {
                        "role": "user",
                        "content": (
                            "Your previous JSON was valid JSON but did not satisfy "
                            "the required analytics-plan schema. Validation errors: "
                            f"{exc.validation_errors}. Correct the reported fields "
                            "and return a complete replacement JSON object. Do not "
                            "use null for required scalar values. For comparison "
                            "operations, use two distinct category values explicitly "
                            "present in the supplied profile; otherwise choose a "
                            "different supported operation. Ensure each KPI and visualization operation_id matches the 'id' field of an operation in the 'operations' list exactly (never use operation types like 'sum' as operation_id). Do not invent values, "
                            "columns, units, or statistics."
                        ),
                    },
                ]
                continue

            except OllamaTimeoutError as exc:
                logger.exception("Ollama timed out while generating the analytics plan.")
                raise AnalyticsPlanningTimeoutError(str(exc)) from exc

            except OllamaConnectionError as exc:
                logger.exception("Ollama is unavailable while generating the analytics plan.")
                raise AnalyticsProviderUnavailableError(str(exc)) from exc

            except Exception as exc:
                # Keep provider-specific exception classes behind the adapter,
                # but preserve a safe actionable message for the API response.
                logger.exception("LLM analytics plan generation failed.")
                raise AnalyticsPlanningError(
                    f"The configured language-model provider could not generate "
                    f"an analytics plan: {exc}"
                ) from exc

            # Small local models can return a syntactically valid narrative
            # plan while leaving all executable arrays empty. Do not send that
            # empty plan to Module 5 when the profile contains analyzable data.
            if not analytical_plan.operations:
                fallback_plan = build_deterministic_fallback_plan(
                    dataset_profile,
                    analytical_plan,
                )
                if fallback_plan is not None:
                    logger.warning(
                        "LLM returned an empty operation list; using a "
                        "conservative profile-grounded deterministic plan."
                    )
                    analytical_plan = fallback_plan

            try:
                validate_analytical_plan(
                    analytical_plan,
                    dataset_profile,
                )
                break

            except AnalyticalPlanValidationError as exc:
                if attempt == 1:
                    logger.exception(
                        "Generated analytics plan failed validation after correction."
                    )
                    raise

                logger.warning(
                    "Generated plan failed deterministic validation; requesting "
                    "one corrected plan. Reason: %s",
                    exc,
                )
                # Keep the repair request compact. Re-sending the entire prior
                # JSON plan as an assistant turn consumes context and often causes
                # small local models to hit their output-token limit on the
                # replacement plan. The authoritative workbook profile and
                # system rules are already present in `messages`.
                request_messages = [
                    *messages,
                    {
                        "role": "user",
                        "content": (
                            "The plan you just generated failed deterministic "
                            "validation. Fix this specific issue and return one "
                            "complete replacement JSON object matching the schema. "
                            f"Validation error: {exc}. "
                            "Do not use a numerical column as a category/group/"
                            "comparison column. For comparison, category_column "
                            "must be a categorical or boolean column, and both "
                            "values must be distinct observed categories from that "
                            "column. If no suitable category exists, omit comparison "
                            "and choose a valid supported operation instead. "
                            "Keep the plan concise: at most 2 operations, 1 "
                            "visualization, and 2 key questions. Do not invent "
                            "columns, values, units, or statistics."
                        ),
                    },
                ]

        if analytical_plan is None:
            # Defensive guard; the loop either returns a plan or raises.
            raise AnalyticsPlanningError(
                "The language model did not produce an analytical plan."
            )

        logger.info(
            "Analytics plan generated and validated successfully."
        )

        return analytical_plan


def generate_analytics_plan(
    dataset_profile: DatasetProfile,
) -> WorkbookAnalyticsPlan:
    """Convenience function for generating a validated analytics plan."""

    planner = AnalyticsPlanner()
    return planner.generate_plan(dataset_profile)
