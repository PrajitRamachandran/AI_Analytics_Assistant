import "./AnalyticsDashboard.css";

function formatNumber(value) {
  if (value === null || value === undefined || value === "") return "—";
  if (typeof value !== "number") return String(value);
  return new Intl.NumberFormat(undefined, { maximumFractionDigits: 2 }).format(value);
}

function BarChart({ chart }) {
  const data = chart.data || [];
  const max = Math.max(...data.map((point) => Math.abs(point.value)), 1);
  const width = 820;
  const rowHeight = 38;
  const height = Math.max(220, data.length * rowHeight + 48);
  const labelWidth = 190;
  const valueWidth = 85;
  const plotWidth = width - labelWidth - valueWidth - 30;

  return (
    <svg className="analytics-svg" viewBox={`0 0 ${width} ${height}`} role="img" aria-label={chart.title}>
      {data.map((point, index) => {
        const y = 24 + index * rowHeight;
        const barWidth = Math.max(2, (Math.abs(point.value) / max) * plotWidth);
        return (
          <g key={`${point.label}-${index}`}>
            <text x={labelWidth - 12} y={y + 19} textAnchor="end" className="chart-axis-label">
              {String(point.label).length > 24 ? `${String(point.label).slice(0, 21)}…` : point.label}
            </text>
            <rect x={labelWidth} y={y + 4} width={barWidth} height="22" rx="5" className="chart-bar" />
            <text x={Math.min(labelWidth + barWidth + 8, width - valueWidth)} y={y + 20} className="chart-value-label">
              {formatNumber(point.value)}
            </text>
          </g>
        );
      })}
    </svg>
  );
}

function LineChart({ chart }) {
  const data = chart.data || [];
  const width = 820;
  const height = 300;
  const left = 64;
  const right = 24;
  const top = 24;
  const bottom = 58;
  const values = data.map((point) => point.value);
  const min = Math.min(...values, 0);
  const max = Math.max(...values, 1);
  const range = max - min || 1;
  const x = (index) => left + (data.length <= 1 ? 0 : index * (width - left - right) / (data.length - 1));
  const y = (value) => top + (max - value) * (height - top - bottom) / range;
  const points = data.map((point, index) => `${x(index)},${y(point.value)}`).join(" ");

  return (
    <svg className="analytics-svg" viewBox={`0 0 ${width} ${height}`} role="img" aria-label={chart.title}>
      {[0, 1, 2, 3].map((tick) => {
        const value = min + (range * tick) / 3;
        const yy = y(value);
        return (
          <g key={tick}>
            <line x1={left} x2={width - right} y1={yy} y2={yy} className="chart-grid-line" />
            <text x={left - 10} y={yy + 4} textAnchor="end" className="chart-axis-label">{formatNumber(value)}</text>
          </g>
        );
      })}
      <polyline points={points} className="chart-line" />
      {data.map((point, index) => (
        <g key={`${point.label}-${index}`}>
          <circle cx={x(index)} cy={y(point.value)} r="4.5" className="chart-point" />
          <text x={x(index)} y={height - 24} textAnchor="middle" className="chart-axis-label">
            {String(point.label).length > 12 ? `${String(point.label).slice(0, 10)}…` : point.label}
          </text>
        </g>
      ))}
    </svg>
  );
}

export default function AnalyticsDashboard({ result }) {
  if (!result) return null;

  return (
    <section className="analytics-dashboard">
      <div className="analytics-dashboard-heading">
        <div>
          <p className="eyebrow">MODULES 4–6 · DETERMINISTIC RESULTS</p>
          <h2>Analytics Dashboard</h2>
          <p className="subtitle">{result.filename} · {result.worksheet_count} worksheet(s) · {formatNumber(result.row_count)} rows analyzed</p>
        </div>
        <span className="analytics-status">Analysis complete</span>
      </div>

      <div className="analytics-kpi-grid">
        {(result.kpis || []).map((kpi) => (
          <article className="analytics-kpi" key={kpi.id}>
            <span>{kpi.label}</span>
            <strong>{formatNumber(kpi.value)}</strong>
          </article>
        ))}
      </div>

      {result.charts?.length ? (
        <div className="analytics-chart-grid">
          {result.charts.map((chart) => (
            <article className="analytics-chart-card" key={chart.id}>
              <div className="analytics-chart-heading">
                <div>
                  <h3>{chart.title}</h3>
                  <p>{chart.description}</p>
                </div>
                <span>{chart.worksheet_name}</span>
              </div>
              <div className="analytics-chart-scroll">
                {["line", "area"].includes(chart.chart_type)
                  ? <LineChart chart={chart} />
                  : <BarChart chart={chart} />}
              </div>
              <p className="analytics-chart-footnote">
                {chart.x_label} · {chart.y_label} · Calculated from workbook rows
              </p>
            </article>
          ))}
        </div>
      ) : (
        <div className="status-message error">
          The plan was generated and executed, but no chartable grouped results were available.
        </div>
      )}

      <article className="analytics-operations-card">
        <h3>Executed analyses</h3>
        {(result.results || []).map((item) => (
          <div className="analytics-operation-row" key={item.operation_id}>
            <div>
              <strong>{item.title}</strong>
              <span>{item.worksheet_name} · {item.operation_type.replaceAll("_", " ")}</span>
            </div>
            {item.value !== undefined ? (
              <strong>{formatNumber(item.value)}</strong>
            ) : (
              <span>{item.records?.length || 0} result row(s)</span>
            )}
          </div>
        ))}
      </article>
    </section>
  );
}
